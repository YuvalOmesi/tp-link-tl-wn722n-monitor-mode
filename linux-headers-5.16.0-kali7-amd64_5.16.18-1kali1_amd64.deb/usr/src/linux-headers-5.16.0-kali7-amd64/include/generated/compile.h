/* This file is auto generated, version 1 */
/* SMP PREEMPT */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#1 SMP PREEMPT Debian 5.16.18-1kali1 (2022-04-01)"
#define LINUX_COMPILE_BY "devel"
#define LINUX_COMPILE_HOST "kali.org"
#define LINUX_COMPILER "gcc-11 (Debian 11.2.0-19) 11.2.0, GNU ld (GNU Binutils for Debian) 2.38"
