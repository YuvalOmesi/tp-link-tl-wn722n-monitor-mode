#define LINUX_PACKAGE_ID " Debian 5.16.18-1kali1"
