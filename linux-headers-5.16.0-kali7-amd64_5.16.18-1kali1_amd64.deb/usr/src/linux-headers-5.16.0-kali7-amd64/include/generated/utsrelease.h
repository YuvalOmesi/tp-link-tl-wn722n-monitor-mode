#define UTS_RELEASE "5.16.0-kali7-amd64"
